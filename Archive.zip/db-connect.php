<?


//connect to the database
mysql_connect('http://146.185.170.24/screenspace', 'root', 'D0yl3r09');  
mysql_select_db('screenspace');

//included charset UTF8 so that the Irish language TV shows on TG4 are understood properly
mysql_query("SET NAMES 'utf8'");


?>

