ScreenSpace
===========

Screen-Space is a Second-Screen App for iPad created by DigitalInc. 

The files in this repo are working-in-progress. 



 
