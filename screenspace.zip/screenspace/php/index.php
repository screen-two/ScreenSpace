<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>This is a pain in my hole</title>
  
</head>
<body>

<header>
	<h1>Screen Space</h1>
	<h2>Welcome...</h2>
</header>
   <div class="content-wrapper">
   		<div class="placeholder-text">
        	<p>You have reached Screen Space, by Digitalinc. All enquiries should be directed to <a href="mailto:hello@mixedmedia.ie">hello@mixedmedia.ie</a>. Thank you for your visit!</p>
        
        	<p>Updated db config</p>
   		</div>
   </div>
</body>
</html>
